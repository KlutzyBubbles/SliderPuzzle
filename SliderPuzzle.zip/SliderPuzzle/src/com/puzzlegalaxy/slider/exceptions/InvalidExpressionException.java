package com.puzzlegalaxy.slider.exceptions;

public class InvalidExpressionException extends Exception {

	private static final long serialVersionUID = 2275682826819871859L;
	
	public InvalidExpressionException(String message) {
		super(message);
	}
	
}
