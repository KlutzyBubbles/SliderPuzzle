package com.puzzlegalaxy.slider.exceptions;

public class InvalidLevelException extends Exception {

	private static final long serialVersionUID = 2275682826819871859L;
	
	public InvalidLevelException(String message) {
		super(message);
	}
	
}
