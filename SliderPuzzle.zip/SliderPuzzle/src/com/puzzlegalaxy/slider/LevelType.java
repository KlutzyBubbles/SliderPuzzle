package com.puzzlegalaxy.slider;

public enum LevelType {

	SAVED, RANDOM, CALCULATED, DEFAULT
	
}
